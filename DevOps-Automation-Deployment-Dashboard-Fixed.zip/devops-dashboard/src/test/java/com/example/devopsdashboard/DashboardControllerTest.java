package com.example.devopsdashboard;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class DashboardControllerTest {
    @Autowired private MockMvc mvc;

    @Test void healthEndpointReturnsUp() throws Exception {
        mvc.perform(get("/api/health")).andExpect(status().isOk()).andExpect(jsonPath("$.status").value("UP"));
    }

    @Test void summaryHasBuildMetrics() throws Exception {
        mvc.perform(get("/api/summary")).andExpect(status().isOk()).andExpect(jsonPath("$.builds").isNumber()).andExpect(jsonPath("$.applicationStatus").value("UP"));
    }

    @Test void deploymentsEndpointReturnsRecords() throws Exception {
        mvc.perform(get("/api/deployments")).andExpect(status().isOk()).andExpect(jsonPath("$[0].version").value("v1.0.8"));
    }
}

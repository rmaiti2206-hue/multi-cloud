package com.example.devopsdashboard;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class DashboardController {
    private final Instant startedAt = Instant.now();
    private final AtomicLong simulatedBuild = new AtomicLong(12);

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of("status", "UP", "service", "devops-automation-dashboard", "checkedAt", Instant.now().toString());
    }

    @GetMapping("/summary")
    public Map<String, Object> summary() {
        return Map.of("builds", simulatedBuild.get(), "successfulBuilds", simulatedBuild.get() - 1,
                "failedBuilds", 1, "deployments", 8, "applicationStatus", "UP",
                "startedAt", startedAt.toString(), "environment", "LOCAL");
    }

    @GetMapping("/deployments")
    public List<Map<String, String>> deployments() {
        return List.of(
                Map.of("version", "v1.0.8", "environment", "LOCAL", "status", "SUCCESS", "time", "Just now"),
                Map.of("version", "v1.0.7", "environment", "LOCAL", "status", "SUCCESS", "time", "25 minutes ago"),
                Map.of("version", "v1.0.6", "environment", "LOCAL", "status", "ROLLED BACK", "time", "Yesterday")
        );
    }

    // Demo endpoint to make the dashboard's build counter interactive. Replace with real Jenkins API data in an extension.
    @PostMapping("/builds/trigger-demo")
    public Map<String, Object> triggerDemoBuild() {
        long number = simulatedBuild.incrementAndGet();
        return Map.of("buildNumber", number, "status", "QUEUED", "message", "Demo build recorded. Configure Jenkins integration for real pipeline triggers.");
    }
}

# DevOps Automation and Deployment Dashboard

A local-first DevOps mini project built with Java 21, Spring Boot, Maven, Jenkins, Docker and GitHub. It provides a dashboard UI, health endpoint, build summary, deployment-history demo data, unit/integration tests, and a Jenkins pipeline.

> **Important:** Build counts and deployment-history entries in this starter are demonstration data, not live Jenkins records. The “Record demo build” button updates an in-memory counter. Jenkinsfile stages perform a real Maven build/test, build a Docker image, deploy it locally, and check `/api/health`. Configure Jenkins tools and Windows agent requirements before running the pipeline.

## Requirements
- JDK 21
- Maven 3.9+
- Docker Desktop running
- Git
- Jenkins with Pipeline and JUnit plugins; configure Jenkins tools named `JDK21` and `Maven3`

## Run locally without Jenkins
```bash
mvn clean test
mvn spring-boot:run
```
The local Spring Boot default is **port 8081** to avoid a conflict with Jenkins on port 8080. Open http://localhost:8081. API endpoints: `/api/health`, `/api/summary`, `/api/deployments`.

## Build and run with Docker
```bash
docker build -t devops-automation-dashboard:1.0 .
docker run --rm --name devops-dashboard -p 8081:8080 devops-automation-dashboard:1.0
```
The container listens on port 8080 internally; the host uses port 8081. Open http://localhost:8081. If host port 8081 is busy, use `-p 8082:8080` and open http://localhost:8082. Stop the Maven-run app before deploying the Docker container on the same host port.

## Jenkins setup (Windows agent)
1. Install Jenkins, Git, JDK 21, Maven 3.9+, and Docker Desktop.
2. In **Manage Jenkins → Tools**, configure JDK name `JDK21` and Maven name `Maven3` with valid local installations or automatic installers.
3. Ensure the Jenkins agent account can run `git`, `mvn`, `docker`, and PowerShell. Docker Desktop must be running for that account.
4. Push this project to GitHub. In Jenkins, create **New Item → Pipeline → Pipeline script from SCM**, select Git, add your repository URL and branch, and set Script Path to `Jenkinsfile`.
5. Run **Build Now** and inspect each stage. Enable GitHub webhook/polling only after the basic pipeline works.

The included Jenkinsfile uses Windows `bat` steps and deploys Docker to host port 8081. Stop any locally running Maven instance on port 8081 before running the deployment stage. For a Linux Jenkins agent, replace `bat` commands with equivalent `sh` commands and adjust the health-check command.

## GitHub upload
```bash
git init
git add .
git commit -m "Add DevOps automation dashboard mini project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/devops-automation-dashboard.git
git push -u origin main
```
Replace the sample remote URL with your repository URL. Do not commit passwords, tokens, or cloud credentials.

## Tests
`DashboardControllerTest` verifies the health, summary, and deployment endpoints. Run `mvn test` to execute them.

## Known limitations and future scope
- Build metrics and deployment history are demo data; integrate Jenkins REST API with a protected token-backed backend for live history.
- The button records a demo build only; it does not trigger Jenkins.
- Add authentication/authorization before exposing the dashboard beyond localhost.
- Optional improvements: GitHub webhook, real Jenkins API integration, persistent deployment database, email/Slack alerts, Prometheus metrics and Grafana dashboards, cloud deployment.

## College report outline
1. Abstract and introduction
2. Problem statement and objectives
3. Existing system vs proposed system
4. Tools and technology stack
5. System architecture and module design
6. Implementation and Jenkins pipeline stages
7. Test cases and results
8. Screenshots of dashboard, Jenkins stages, and Docker container
9. Limitations and future enhancements
10. Conclusion and references

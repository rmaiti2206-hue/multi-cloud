# Port 8080 conflict fix

The local Spring Boot app now defaults to port 8081 (`src/main/resources/application.properties`):

```properties
server.port=${SERVER_PORT:8081}
```

Run locally with `mvn spring-boot:run`, then open http://localhost:8081. Jenkins can continue using port 8080.

The Docker image sets `SERVER_PORT=8080` inside the container, so the existing mapping `-p 8081:8080` and Jenkins health check continue to work. Do not run the Maven app and the Docker container simultaneously on host port 8081. If port 8081 is busy, map another host port, e.g. `-p 8082:8080`, and open http://localhost:8082.
